# gb_design_patterns
### Архитектура и шаблоны проектирования на Python курс на gb.ru

**For start up server** : 
<br>

    gunicorn main:application