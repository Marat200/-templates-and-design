import os
from pathlib import Path
PROJECT_ROOT = Path(__file__).parent
TEMPLATE_DIR = os.path.join(Path(__file__).parent, 'templates')
